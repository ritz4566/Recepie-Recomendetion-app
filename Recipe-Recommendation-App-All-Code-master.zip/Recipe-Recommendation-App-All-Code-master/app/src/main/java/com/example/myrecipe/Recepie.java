package com.example.myrecipe;

public class Recepie {

    private String RecepieName;

    public Recepie(String recepieName) {
        RecepieName = recepieName;
    }

    public String getRecepieName() {
        return RecepieName;
    }
}
