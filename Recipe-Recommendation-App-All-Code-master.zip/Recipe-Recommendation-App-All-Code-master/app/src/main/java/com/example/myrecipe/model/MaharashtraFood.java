package com.example.myrecipe.model;

public class MaharashtraFood {

    String name;

    String imageUrl;

  /*  public AsiaFood(String name, Integer imageUrl) {
        this.name = name;

        this.imageUrl = imageUrl;

    }*/






    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
